# practice > 2024-04-25 3:38pm
https://universe.roboflow.com/paramesh-xuqj2/practice-rb1yw

Provided by a Roboflow user
License: CC BY 4.0

